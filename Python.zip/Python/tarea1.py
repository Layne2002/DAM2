import shutil
print("hola mundo")  # imprime el hola mundo

cadena1 = "hola1"+"mundo1"
print(cadena1)
edad = input("Edad:")
print("Tienes:"+edad+" años")
a = list("numeros")
print(a)
# Esto es un comentario del código y es ignorado
x = 250*250
print("El resultado es:"+str(x))

print("xD2")
print("dada")
print("El tipo de dato "+str(type(x)))

for i in "dada tonto":
    print(i)
