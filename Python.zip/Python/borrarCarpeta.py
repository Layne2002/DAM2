import shutil

carpeta = "C:\\Users\\dam2\\Desktop\\Nueva carpeta"

# Eliminar la carpeta y todo su contenido
shutil.rmtree(carpeta)
