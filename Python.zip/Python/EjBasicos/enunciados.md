
# CONCEPTOS BÁSICOS

1. Escriba un programa que recoja un valor por teclado y muestre de qué tipo es.

2. Escribe un programa que recoja dos números enteros por teclado y muestre los siguientes resultados: suma, resta, multiplicación, división real, división entera, resto de la división entera y potencia.

3. Escribe un programa que pida el nombre del usuario y le responda con un saludo. En el saludo deberá utilizarse el nombre que introdujo el usuario.

4. Escribe un programa que recoja tres números y calcule su media aritmética.

5. Escribe un programa que recoja un número y muestre su valor absoluto.

6. Escribe un programa que recoja las notas de las tres evaluaciones de un alumno. A continuación debe calcular y mostrar la nota final, teniendo en cuenta que la primera evaluación cuenta un 20% de la nota final, la segunda evaluación un 35% y la tercera evaluación un 45%.

7. Escribe un programa que recoja un número y muestre su representación en código binario.

8. Escribe un programa que recoja un texto y lo muestre cinco veces consecutivas en la misma línea.

9. Escribe un programa que recoja un texto y que muestre su longitud,

10. Escribe un programa que recoja la edad del usuario y muestre la edad que tendrá dentro de 5, 10 y 15 años.
