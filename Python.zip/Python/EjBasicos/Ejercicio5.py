num = int(input("Introduce un número y te diré su valor absoluto:\n"))
print("El valor absoluto de ", num, " es: ", abs(num))
