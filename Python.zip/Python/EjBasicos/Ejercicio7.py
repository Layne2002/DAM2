numero = int(input("Dime un número y te lo diré en binario:\n"))
binario = bin(numero)
print(binario[2:])
