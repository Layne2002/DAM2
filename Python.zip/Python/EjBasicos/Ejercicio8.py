cadena = input("Escripe una cadena de texto\n")
print(cadena*5)
