valor = input("Escribe algo!")
# valor2 = 2
print("El valor es del tipo: ", type(valor))
# print(type(valor)+type(valor2))
