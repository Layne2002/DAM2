nombre = input("Hola! Cómo te llamas?")
print("Hola, "+nombre+"!")
