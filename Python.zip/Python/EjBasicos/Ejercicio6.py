nota1 = float(input("Introduce la nota de la primera evaluación:\n"))
nota2 = float(input("Introduce la nota de la segunda evaluación:\n"))
nota3 = float(input("Introduce la nota de la tercera evaluación:\n"))
media = nota1*0.2 + nota2*0.35 + nota3*0.45
print("La media del alumno es: ", media)
