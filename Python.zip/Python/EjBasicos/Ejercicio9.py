cadena = input("Dime una cadena de texto:\n")
print("La longitud de la cadena es ", len(cadena))
