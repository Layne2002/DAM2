cadena = input("Escribe una cadena de texto:\n")
for i in cadena:
    print(i)
