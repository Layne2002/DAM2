# SENTENCIAS DE SECUENCIAS

1- Escribe un programa que recoja números de teclado hasta que se introduce un cero.
Luego debe mostrar la secuencia de números de tres modos:
a. En el orden en que se introdujeron.
b. En orden creciente.
c. En orden decreciente.
Ejemplo: si se introduce 4 3 5 2 0, debe mostrarse:

```.Spanish
- 4 3 5 2
- 2 3 4 5
- 5 4 3 2
```

2- Repite el ejercicio anterior, pero ahora lo que se leen son textos. La condición
de finalización será la cadena vacía.

3- Escribe un programa lea un texto y determine si es un palíndromo. Procura
crear una función palindromo(s) -> Bool.
NOTA: una cadena es palíndromo si se lee igual de izquierda a derecha que
de derecha a izquierda. Por ejemplo, la palabra OSO es un palíndromo.

4- Escribe un programa que lea dos textos y compruebe si una es palíndromo de la otra.
El programa debe preguntar si se desea comprobar teniendo en cuenta
mayúsculas/minúsculas o no.
