x = int(input("Introduce un número y te diré si es par o impar:\n"))
if (x % 2 == 0):
    print("es par")
else:
    print("es impar")
