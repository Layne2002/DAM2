dividendo = int(input("dime el dividendo:\n"))
divisor = int(input("dime el divisor\n"))
if (divisor != 0):
    print("El resultado de la division es: ", dividendo/divisor)
else:
    print("No se puede dividir por cero")
